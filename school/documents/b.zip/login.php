<?php
    $db = mysqli_connect('localhost','root','','STUDMANBORROMEE');
    if(!$db){
        echo "Database Connection Failed !";
    }
    
    $action = $_POST['action'];
    if('LOGIN' == $action){
        
        // $login = $_POST['login'];
        $login = $_POST['login'];;
        $text_password = $_POST['text_password'];
        
        $db_data = array();
        $sql = "SELECT * FROM users WHERE login = '$login' AND text_password = '$text_password'";
        $result = mysqli_query($db,$sql);
        $count = mysqli_num_rows($result);
        
        if($count > 0){
            while($row = $result->fetch_assoc()){
                $db_data[] = $row;
            }
            echo json_encode($db_data);
        }else{
            echo json_encode("Error");
        }
        $db->close;
        return;
    }

    if('CHANGE PASSWORD' == $action){
        
        // $login = $_POST['login'];
        $login = $_POST['login'];
        $new_password = $_POST['new_password'];
        
        // $db_data = array();
        $sql = "UPDATE users SET text_password = '$new_password' WHERE login = '$login'";
        $result = mysqli_query($db,$sql);
        // $count = mysqli_num_rows($result);
        
        echo json_encode("Success");
        
        $db->close;
        return;
    }

    if('GET_ALL' == $action){
        $db_data = array();
        $sql = "SELECT * FROM users";
        $result = mysqli_query($db,$sql);
        $count = mysqli_num_rows($result);
        
        if($count > 0){
            while($row = $result->fetch_assoc()){
                $db_data[] = $row;
            }
            echo json_encode($db_data);
        }else{
            echo "Error";
        }
        $db->close;
        return;
    }
?>